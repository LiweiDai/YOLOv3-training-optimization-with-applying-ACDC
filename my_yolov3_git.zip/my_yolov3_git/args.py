# coding: utf-8
from __future__ import division, print_function
from utils.misc_utils import parse_anchors, read_class_names
import math

train_file = './data/my_data/....txt'
val_file = './data/my_data/....txt'
restore_path = './data/darknet_weights/....ckpt'
save_dir = './checkpoint/...'
log_dir = './data/logs/...'
progress_log_path = './data/....log'
anchor_path = './data/....txt'
class_name_path = './data/....names'

batch_size = 6
img_size = [416, 416]
letterbox_resize = True
total_epoches = 100
train_evaluation_step = 100
val_evaluation_epoch = 2
save_epoch = 10
batch_norm_decay = 0.99
weight_decay = 5e-4
global_step = 0
num_threads = 10
prefetech_buffer = 5

optimizer_name = 'momentum'
save_optimizer = True
learning_rate_init = 1e-4
lr_type = 'piecewise'
lr_decay_epoch = 5
lr_decay_factor = 0.96
lr_lower_bound = 1e-6
pw_boundaries = [30, 50]
pw_values = [learning_rate_init, 3e-5, 1e-5]

restore_include = None
restore_exclude = ['yolov3/yolov3_head/Conv_14', 'yolov3/yolov3_head/Conv_6', 'yolov3/yolov3_head/Conv_22']
update_part = ['yolov3/yolov3_head']

multi_scale_train = True
data_augmentation = True
use_jitter = True
use_warm_up = True
warm_up_epoch = 1
use_acdc = False
use_acdc_in_box = False
nms_threshold = 0.5
score_threshold = 0.01
nms_topk = 200
eval_threshold = 0.5
anchors = parse_anchors(anchor_path)
classes = read_class_names(class_name_path)
class_num = len(classes)
train_img_cnt = len(open(train_file, 'r').readlines())
val_img_cnt = len(open(val_file, 'r').readlines())
train_batch_num = int(math.ceil(float(train_img_cnt) / batch_size))
lr_decay_freq = int(train_batch_num * lr_decay_epoch)
pw_boundaries = [float(i) * train_batch_num + global_step for i in pw_boundaries]
